import json

import numpy as np
from functools import reduce


def analyze(keyword, result):
    count = len(result)
    if count > 0:
        fenci_list=[]
        try:
            fenci_list = json.loads(result[0].get("fenciWords"))
        except:
            pass
        fenci_list.append(keyword)
        np_count = np.longdouble(count)
        anim_count = len(
            list(filter(lambda x: int(x['is_animated']) == 1, result)))
        anim_ratio = np.divide(np.longdouble(anim_count), np.longdouble(
            count)) if count != 0 else np.longdouble(0)
        avg_size = reduce(lambda x, y: np.add(x, np.divide(
            y, np_count)), map(lambda x: np.longdouble(x['fsize']), result))
        match_detail = [1 if sum(list(map(lambda i:1 if i.lower() in x['text'] else 0,fenci_list)))>0
                        else 0 for x in result]
        match_count = reduce(
            lambda x, y: x+y, match_detail)
        match_ratio = np.divide(np.longdouble(match_count), np_count)
        return {
            'attr': {
                'count': {
                    'value': count,
                    'desc': '结果数量，大于100显示为100'
                },
                'anim_ratio': {
                    'value': anim_ratio.astype(float),
                    'desc': '动图占比'
                },
                'match_ratio': {
                    'value': match_ratio.astype(float),
                    'desc': 'text含有关键词的图片占比'
                },
                'avg_size': {
                    'value': avg_size.astype(float),
                    'desc': '文件平均字节数'
                }
            },
            'score': {
                'value': np.multiply(np.multiply(np_count, anim_ratio), match_ratio).astype(float),
                'desc': '分数，除平均字节数之外几项的积'
            }
        }
    else:
        return {}
