#!/usr/bin/env python3
# coding:utf-8
from enum import Enum, unique
import json

##常量
FIELD_KEY = "field_key"
FIELD_NAME = "field_name"

all_keyword_score_versions = ['v1', 'v2']

##排序类型
class orderType(Enum):
    DESC = "DESC"
    ASC = "ASC"
    NONE = "NONE" ##不按该字段排序

def get_score_base_api(version):
    if version == "v1":
        # return "http://116.62.167.76:8000"
        return "http://localhost:8000"
    elif version == "v2":
        # return "http://116.62.167.76:8000/v2"
        return "http://localhost:8000/v2"

def get_score_result_table_with_version(version):
    if version == "v1":
        return "keyword_score_v1"
    elif version == "v2":
        return "keyword_score_v2"
    return ""    

def get_order_fields_with_version(version):
    orderFields = [{FIELD_KEY:"weight", FIELD_NAME:"权重"},
                   {FIELD_KEY:"score", FIELD_NAME:"评分"},
                   {FIELD_KEY:"is_core", FIELD_NAME:"是否核心词"},
                   {FIELD_KEY:"maintain", FIELD_NAME:"是否运营过"},
                   {FIELD_KEY:"image_count", FIELD_NAME:"图片数量"},
                   {FIELD_KEY:"anim_ratio", FIELD_NAME:"动图占比"},
                   {FIELD_KEY:"match_ratio", FIELD_NAME:"关键词匹配占比"}]
    if version == "v1":
        orderFields.append({FIELD_KEY:"avg_size", FIELD_NAME:"图片大小"})
    elif version == "v2":
        otherFields = [{FIELD_KEY:"quality_score", FIELD_NAME:"质量评分"},
                       {FIELD_KEY:"size_adequate_ratio", FIELD_NAME:"清晰度合适占比"},
                       {FIELD_KEY:"distribution_score", FIELD_NAME:"分布评分"},
                       {FIELD_KEY:"anim_distribution_score", FIELD_NAME:"动图分布情况评分"},
                       {FIELD_KEY:"size_distribution_score", FIELD_NAME:"清晰度分布情况评分"},
                       {FIELD_KEY:"match_distribution_score", FIELD_NAME:"关键词匹配分布情况评分"}]
        orderFields = orderFields + otherFields
    return orderFields

class KeywordScoreVersion:
    def __init__(self, version):
        if version not in all_keyword_score_versions:
            raise ValueError("invalid version!") 
        self.version = version
        self.score_result_table = get_score_result_table_with_version(version)
        self.score_base_api = get_score_base_api(version)
        self.orderFields = get_order_fields_with_version(version)
    
    def get_version_instance(self):
        dic = {}
        dic['version'] = self.version
        dic['score_result_table'] = self.score_result_table
        dic['order_fields'] = self.orderFields
        return dic

    def get_keyword_instance(self, reTuple):
        if self.version == "v1":
            return wordVersion1(reTuple)
        elif self.version == "v2":
            return wordVersion2(reTuple)


def wordVersion1(reTuple):
    dic = {}
    dic["guid"] = reTuple[0]
    dic["category"] = reTuple[1]
    dic["text"] = reTuple[2]
    dic["weight"] = reTuple[3]
    dic["is_core"] = reTuple[4]
    dic["maintain"] = reTuple[5]
    dic["clevel"] = reTuple[6]
    dic["kind"] = reTuple[7]
    dic["score"] = reTuple[8]
    # dic["score_des"] = json.loads(reTuple[9])
    dic["image_count"] = reTuple[10]
    dic["anim_ratio"] = reTuple[11]
    dic["match_ratio"] = reTuple[12]
    dic["avg_size"] = reTuple[13]
    dic["search_type"] = reTuple[14]
    return dic

def wordVersion2(reTuple):
    dic = {}
    dic["guid"] = reTuple[0]
    dic["category"] = reTuple[1]
    dic["text"] = reTuple[2]
    dic["weight"] = reTuple[3]
    dic["is_core"] = reTuple[4]
    dic["maintain"] = reTuple[5]
    dic["clevel"] = reTuple[6]
    dic["kind"] = reTuple[7]
    dic["score"] = reTuple[8]
    dic["image_count"] = reTuple[9]
    dic["quality_score"] = reTuple[10]
    dic["anim_ratio"] = reTuple[11]
    dic["size_adequate_ratio"] = reTuple[12]
    dic["match_ratio"] = reTuple[13]
    dic["distribution_score"] = reTuple[14]
    dic["anim_distribution_score"] = reTuple[16]
    dic["size_distribution_score"] = reTuple[18]
    dic["match_distribution_score"] = reTuple[20]
    if int(dic["image_count"]) > 0:
        dic["anim_distribution_detail"] = json.loads(reTuple[15])
        dic["size_distribution_detail"] = json.loads(reTuple[17])
        dic["match_distribution_detail"] = json.loads(reTuple[19])
        # dic["meta_data"] = json.loads(reTuple[21])
    dic["search_type"] = reTuple[22]

    return dic

def resolve_score_result_from_score_api_with_version(version, data, result):
    if version == "v1":
        score = 0.0
        score_des = ""
        image_count = 0
        anim_ratio = 0.0
        match_ratio = 0.0
        avg_size = 0.0
        search_type = -1
        try:
            image_count = result["attr"]["count"]["value"]
            anim_ratio = result["attr"]["anim_ratio"]["value"]
            match_ratio = result["attr"]["match_ratio"]["value"]
            avg_size = result["attr"]["avg_size"]["value"]
            score_des = json.dumps(result)
            score = result["score"]["value"]
            search_type = int(result["search_type"])
        except Exception as e:
            pass
            # print(data[2], ": 无搜索结果")
        return data + (score, score_des, image_count, anim_ratio, match_ratio, avg_size,search_type)

    elif version == "v2":
        score = 0.0
        image_count = 0
        quality_score = 0.0
        anim_ratio = 0.0
        size_adequate_ratio = 0.0
        match_ratio = 0.0
        distribution_score = 0.0
        anim_distribution_detail = ""
        anim_distribution_score = 0.0
        size_distribution_detail = ""
        size_distribution_score = 0.0
        match_distribution_detail = ""
        match_distribution_score = 0.0
        meta_data = ""
        search_type = -1
        fenci_result = ""
        try:
            re = result
            score = str(re["score"]["value"])
            image_count = str(re["attr"]["quantity"]["count"]["value"])
            quality_score = str(re["attr"]["quality"]["score"])
            anim_ratio = str(re["attr"]["quality"]["anim_ratio"]["score"])
            size_adequate_ratio = str(re["attr"]["quality"]["size_adequate_ratio"]["score"])
            match_ratio = str(re["attr"]["quality"]["match_ratio"]["score"])
            distribution_score = str(re["attr"]["distribution"]["score"])
            anim_distribution_detail = json.dumps(re["attr"]["distribution"]["anim_detail"]["value"])
            anim_distribution_score = str(re["attr"]["distribution"]["anim_detail"]["score"])
            size_distribution_detail = json.dumps(re["attr"]["distribution"]["size_detail"]["value"])
            size_distribution_score = str(re["attr"]["distribution"]["size_detail"]["score"])
            match_distribution_detail = json.dumps(re["attr"]["distribution"]["match_detail"]["value"])
            match_distribution_score = str(re["attr"]["distribution"]["match_detail"]["score"])
            meta_data = json.dumps(re["attr"]["meta_data"])
            search_type = int(re["search_type"])
            fenci_result = str(re["fenci_result"])
        except Exception as e:
            pass
            # print(data[2], ": 无搜索结果")
        
        return data + (score, image_count, quality_score, anim_ratio, size_adequate_ratio, 
            match_ratio, distribution_score, anim_distribution_detail, anim_distribution_score, size_distribution_detail,
            size_distribution_score, match_distribution_detail, match_distribution_score, meta_data,search_type,fenci_result)