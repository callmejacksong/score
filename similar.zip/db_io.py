#!/usr/bin/env python3
# coding:utf-8

import pymysql as db
import json
from models import *
from threading import Timer

class DBManager:
    def __init__(self):
        self.src_db = db.connect('rm-bp15gczz2b6835281.mysql.rds.aliyuncs.com', 'bqss', '665Fbt7Nxkcj', 'net_pic', charset="utf8") # 正式库连接
        self.src_cursor = self.src_db.cursor()
        # self.dst_db = db.connect('rm-bp1664spovq6woabo7o.mysql.rds.aliyuncs.com', 'ori', 'Aa123456', 'experiment', charset="utf8")
        self.dst_db = db.connect('rm-bp193jd033arhn169.mysql.rds.aliyuncs.com', 'bqss', '665Fbt7Nxkcj', 'search_expirement', charset="utf8") # 测试库连接
        self.dst_cursor = self.dst_db.cursor()

        # self.test_db = db.connect('rm-bp193jd033arhn169.mysql.rds.aliyuncs.com', 'bqss', '665Fbt7Nxkcj', 'net_pic', charset="utf8") # 测试库连接
        # self.test_cursor = self.test_db.cursor()
        # self.check_database_loop()
    
    def check_database_loop(self):
        t = Timer(3600, self.check_database_loop)
        t.start()
        sql = "select count(guid) from keyword_score_v1;"
        self.dst_cursor.execute(sql)
        print("check dadabase ",self.dst_cursor.fetchall()[0][0])

    def __enter__(self):
        return self;

    def __exit__(self, exc_type, exc_value, traceback):
        self.src_db.close()
        self.dst_db.close()


    def commit(self):
        self.dst_db.commit()

    def rollback(self):
        self.dst_db.rollback()

    def get_keywords(self, offset):
        # self.src_cursor.execute('SELECT guid, category, text, weight, is_core, maintain, clevel, kind from `keyword_net` where is_core = 1 or maintain = 1 order by guid limit 5 offset {};'.format(offset))
        self.src_cursor.execute('SELECT guid, category, text, weight, is_core, maintain, clevel, kind from `keyword_net` where is_core = 1 or maintain = 1 order by guid limit 400,50000;')
        return self.src_cursor.fetchall()

    def get_operate_keywords(self, offset):
        # self.src_cursor.execute('SELECT guid, category, text, weight, is_core, maintain, clevel, kind from `keyword_net` where is_core = 1 or maintain = 1 order by guid limit 5 offset {};'.format(offset))
        self.dst_cursor.execute('SELECT guid, category, text, weight, is_core, maintain, clevel, kind from `operated_keyword`  order by create_time ;')
        return self.dst_cursor.fetchall()


    def get_new_dict_keywords(self, offset):
        self.dst_cursor.execute('SELECT guid, category, text, weight, is_core, maintain, clevel, kind from `new_dict_keyword`  order by create_time ;')
        return self.dst_cursor.fetchall()


    def get_keyword_info(self,keyword):
        self.src_cursor.execute("SELECT guid, category, text, weight, is_core, maintain, clevel, kind from `keyword_net` where text ='{}';".format(keyword.strip()))
        rs = self.src_cursor.fetchall()
        if len(rs)>0:
            return rs[0]
        return ()

    def get_keywords_from_exist_result_keywords(self, offset):
        self.src_cursor.execute('SELECT guid, "", text, weight, -1, -1, -1, -1 from `exist_result_keyword` order by guid limit 5 offset {};'.format(offset))
        return self.src_cursor.fetchall()


    ########################start####################
    def no_result_keywords(self, keyword_score_version, size=50, page=1, is_core=True, is_maintain=True, order_fields=[]):
        """
        无查询结果的词
        参数
        ----------
        keyword_score_version : KeywordScoreVersion 词库评分版本
        size : int 查询数量
        page : int 页码 从1开始
        is_core : Bool 是否只查询核心词
        is_maintain : Bool 是否只查询运营过的词
        order_fields : [(order_field, order_type)] 排序字段及排序类型的元组数组

        返回值
        -------
        词的数组, 词的总数
        """
        offsetPage = page - 1
        if offsetPage < 0:
            offsetPage = 0
        offset = offsetPage * size

        orderSql = ""
        for order in order_fields:
            field, orderType = order
            if orderType != orderType.NONE:
                if orderSql == "":
                    orderSql = "ORDER BY {} {} ".format(field, orderType.value)
                else:
                    orderSql = orderSql + ", {} {} ".format(field, orderType.value)

        whereSql = ""
        if is_core:
            whereSql = whereSql + " and is_core = 1 "
        if is_maintain:
            whereSql = whereSql + " and maintain = 1 "
            
        sql = "select * from {} where image_count = 0 {} {} limit {} offset {};".format(keyword_score_version.score_result_table, whereSql, orderSql, str(size), str(offset))
        print(sql)
        self.dst_cursor.execute(sql)
        res = self.dst_cursor.fetchall()

        countsql = "select count(guid) from {} where image_count = 0 {};".format(keyword_score_version.score_result_table, whereSql)
        print(countsql)
        self.dst_cursor.execute(countsql)
        countRes = self.dst_cursor.fetchall()
        totalCount = countRes[0][0]

        return [keyword_score_version.get_keyword_instance(re) for re in res], totalCount


    def all_keywords(self, keyword_score_version, size=50, page=1, is_core=True, is_maintain=True, order_fields=[]):
        """
        查看关键词
        参数
        ----------
        keyword_score_version : KeywordScoreVersion 词库评分版本
        size : int 查询数量
        page : int 页码 从1开始
        is_core : Bool 是否只查询核心词
        is_maintain : Bool 是否只查询运营过的词
        order_fields : [(order_field, order_type)] 排序字段及排序类型的元组数组

        返回值
        -------
        词的数组, 词的总数
        """
        offsetPage = page - 1
        if offsetPage < 0:
            offsetPage = 0
        offset = offsetPage * size

        orderSql = ""
        for order in order_fields:
            field, orderType = order
            if orderType != orderType.NONE:
                if orderSql == "":
                    orderSql = "ORDER BY {} {} ".format(field, orderType.value)
                else:
                    orderSql = orderSql + ", {} {} ".format(field, orderType.value)

        whereSql = ""
        if is_core:
            whereSql = "where"
            whereSql = whereSql + " is_core = 1 "
            if is_maintain:
                whereSql = whereSql + " and maintain = 1 "
        else:
            if is_maintain:
                whereSql = "where"
                whereSql = whereSql + " maintain = 1 "
            
        sql = "select * from {} {} {} limit {} offset {};".format(keyword_score_version.score_result_table, whereSql, orderSql, str(size), str(offset))
        print(sql)
        self.dst_cursor.execute(sql)
        res = self.dst_cursor.fetchall()

        countsql = "select count(guid) from {} {} ;".format(keyword_score_version.score_result_table, whereSql)
        print(countsql)
        self.dst_cursor.execute(countsql)
        countRes = self.dst_cursor.fetchall()
        totalCount = countRes[0][0]

        return [keyword_score_version.get_keyword_instance(re) for re in res], totalCount


    def get_single_word_score_result(self, keyword_score_version, word):
        """
        单个关键词评分结果
        ----------
        keyword_score_version : KeywordScoreVersion 词库评分版本
        word : str 查询数量
        """
        # try:
        sql = "select * from {} where text = '{}';".format(keyword_score_version.score_result_table, word)
        print(sql)
        self.dst_cursor.execute(sql)
        res = self.dst_cursor.fetchall()
        return [keyword_score_version.get_keyword_instance(re) for re in res]
        # except (Exception) as e:
        #     print(e)
        #     return []

    ########################end####################


    #评分算法V1
    def insert_scored_keywords(self, keywordsData):
        self.dst_cursor.executemany("""INSERT IGNORE INTO keyword_score_v1 VALUES 
                                       (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                                keywordsData)
                                

    ## 验证相关
    def all_core_keyword_with_result_score(self):
        self.dst_cursor.execute('select score from keyword_score_v1 where is_core = 1 and  score_des != "{}"')
        return self.dst_cursor.fetchall()


    def all_keyword_with_result_score(self):
        self.dst_cursor.execute('select score from keyword_score_v1 where score_des != "{}"')
        return self.dst_cursor.fetchall()


    def get_unextract_results(self, offset):
        print(offset)
        self.dst_cursor.execute('select guid, score_des from keyword_score_v1 where score_des != "{}" order by guid limit 100 offset {}'.format("{}", str(offset)))
        return self.dst_cursor.fetchall()


    def get_score_results(self, search_type):
        self.dst_cursor.execute('select c.score,c.image_count,c.quality_score,c.anim_ratio,c.size_adequate_ratio,c.match_ratio,c.distribution_score,c.anim_distribution_score,c.size_distribution_score,c.match_distribution_score,c.search_type from (select * from keyword_score_v2 where search_type=1) as a inner join (select * from keyword_score_v2 where search_type=2) as b on a.text=b.text inner join (select * from keyword_score_v2 where search_type=3) as c on b.text=c.text;')
        return self.dst_cursor.fetchall()
    def get_score_results_1(self, search_type):
        self.dst_cursor.execute('select guid,text,score from keyword_score_v2 ;')
        return self.dst_cursor.fetchall()
    def get_similar_words(self, search_type):
        self.dst_cursor.execute('select * from similar_words order by word ;')
        return self.dst_cursor.fetchall()
    def get_similar_words_by_word_guid(self,word_guid):
        self.dst_cursor.execute('select word,similar_word,word_guid,similar_word_guid,similar_ratio from similar_words where word_guid=%s order by similar_ratio desc limit 5;', (word_guid,))
        return self.dst_cursor.fetchall()
    def get_relative_words_by_word_guid(self,word_guid):
        self.src_cursor.execute('select keyword_id,relation_id,seq,sfrom from keyword_relation where keyword_id=%s and seq>0 order by seq desc ;', (word_guid,))
        return self.src_cursor.fetchall()

    def get_relative_words_guid(self):
        self.dst_cursor.execute(
            'select keyword_id from keyword_relation group by keyword_id ;')
        return self.dst_cursor.fetchall()

    def get_similar_words_1(self, search_type):
        self.src_cursor.execute("""select e.*,f.our_similar_words from (select a.text,a.image_count,a.match_ratio,b.similar_words,'||分割线||' from keyword_score_v2 as a inner join (select word,group_concat(similar_word) as similar_words from similar_words group by word) as b on a.text=b.word  order by a.score asc limit 500) as e left join (select aa.text,group_concat(cc.text) as our_similar_words from keyword_net as aa inner join keyword_relation as bb on aa.guid=bb.keyword_id inner join keyword_net as cc on bb.relation_id=cc.guid group by aa.text) as f on e.text=f.text;""")
        return self.src_cursor.fetchall()


    
    def update_keyword_result_attr(self, attrTupleArr):
        self.dst_cursor.executemany("""update keyword_score_v1 set image_count = %s, anim_ratio = %s, match_ratio = %s, avg_size = %s 
                                        where guid = %s""",
                                    attrTupleArr)



    #评分算法V2
    def insert_scored_keywords_v2(self, keywordsData):
        self.dst_cursor.executemany("""INSERT IGNORE INTO keyword_score_v2 VALUES 
                                       (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s)""",
                                keywordsData)
        print(keywordsData)

    def insert_core_keyword(self,keywordsData):
        self.dst_cursor.executemany("insert ignore into operated_keyword(text) values (%s)",keywordsData)

    def insert_data(self,keywordsData):
        self.dst_cursor.executemany("insert ignore into new_dict_keyword(text) values (%s)",keywordsData)

    def insert_relation_words(self,keywordsData):
        # self.test_cursor.executemany("insert  into keyword_relation_test(keyword_id,relation_id,seq,sfrom) values (%s,%s,%s,%s) on duplicate key update seq=%s",keywordsData)
        self.dst_cursor.executemany("insert ignore into keyword_relation_test(keyword_id,relation_id,seq,sfrom) values (%s,%s,%s,%s) ",keywordsData)


    def insert_relation_words_2(self,keywordsData):
        # self.test_cursor.executemany("insert  into keyword_relation_test(keyword_id,relation_id,seq,sfrom) values (%s,%s,%s,%s) on duplicate key update seq=%s",keywordsData)
        self.dst_cursor.executemany("insert ignore into keyword_relation_test_2(keyword_id,relation_id,seq,sfrom) values (%s,%s,%s,%s) ",keywordsData)

