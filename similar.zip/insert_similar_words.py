
from db_io import DBManager
import json


db = DBManager()
offset = 0
leftCount = 1


def change_weight():
    keyword_ids = db.get_relative_words_guid()
    for keyword_info in keyword_ids:
        relation_words = list(db.get_relative_words_by_word_guid(keyword_info[0]))

        if len(relation_words)>0:
            relation_words=list(map(lambda x: list(x), relation_words))
            for i,data in enumerate(relation_words):
                data[2]=max(500,len(relation_words))-i
            db.insert_relation_words_2(relation_words)
            db.commit()




def insert_rela():


    keywords = db.get_score_results_1(3)##keyword_net表里maintain=1的词


    for count,word_info in enumerate(keywords):
        word_guid=word_info[0].strip()
        word=word_info[1].strip()
        score=float(word_info[2])
        print("进行到",count,word_info)

        similar_words = list(db.get_similar_words_by_word_guid(word_guid))
        if len(similar_words)>0:
            similar_words = list(map(lambda x: list(x[2:]) + [3], similar_words))
        print("近义词是",similar_words)
        relative_words = list(db.get_relative_words_by_word_guid(word_guid))
        if len(relative_words) >0:
            relative_words = list(map(lambda x: list(x), relative_words))
        print("相似词是", relative_words)
        insert_datas = []
        if score>=60:
            insert_datas=relative_words[:5]+similar_words+relative_words[5:]
        else:
            insert_datas=similar_words+relative_words
        if len(insert_datas)>0:
            for i,data in enumerate(insert_datas):
                data[2]=max(500,len(insert_datas))-i
            print("要擦入的词是", insert_datas)
            # for datas in insert_datas:
                # pass
            db.insert_relation_words(insert_datas)
            db.commit()

    print("wanle")


if __name__ == '__main__':
    insert_rela()
    # change_weight()