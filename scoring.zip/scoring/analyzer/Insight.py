import json
import time

import falcon
import requests
import urllib.parse as up
import insight.analyze_result as ar

urls=["http://localhost:10001/gifs/search","http://localhost:10001/gifs/search_fenci","http://localhost:10001/gifs/search_textinfo_fenci"]

def get_result(url,keyword, size=100):
    # url = 'http://localhost:8080/melink-open-api/results/by-q/'+keyword
    params = {
        'size': size,
        'q': keyword,
        'app_id': "5bfca498723c11e98b7b7cd30ae45d00",
        'timestamp': int(time.time())
    }
    r = requests.get(url, params, timeout=9000)
    return json.loads(r.text)


def handle_keyword(keyword):

    result_docs=[]
    for i,url in enumerate(urls):
        doc = {}
        gif_list = []
        try:
            response = get_result(url,keyword, 100)
            if response['data'] is not None:
                gif_list.extend(response['data'])
                print(list(filter(lambda x: int(x['is_animated']) == 1, gif_list)))
            doc = ar.analyze(keyword, gif_list)
            doc["search_type"] = i+1
            result_docs.append(doc)
        except:
            pass

    return result_docs


class Resource(object):

    def on_get(self, req, resp, keyword):
        resp.body = json.dumps(handle_keyword(
            keyword), ensure_ascii=False, indent=4)
        resp.status = falcon.HTTP_200


class Batch(object):
    def on_get(self, req, resp):
        doc = {}
        try:
            keywords = json.loads(up.unquote(req.query_string))
            for keyword in keywords:
                doc[keyword] = handle_keyword(keyword)
        except:
            pass
        resp.body = json.dumps(doc, ensure_ascii=False, indent=4)

    def on_post(self, req, resp):
        doc = {}
        try:
            keywords = json.load(req.stream)
            for keyword in keywords:
                print(keyword)
                doc[keyword] = handle_keyword(keyword)
        except:
            pass
        resp.body = json.dumps(doc, ensure_ascii=False, indent=4)
