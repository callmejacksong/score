#!/usr/bin/env python3

import falcon
import falcon_cors as flc
import bjoern
from ipaddress import ip_address
import Insight as ins
import Insight2 as ins2

public_cors = flc.CORS(allow_all_origins=True)

wsgi_app = api = application = falcon.API(middleware=[public_cors.middleware])
api.req_options.auto_parse_form_urlencoded = True

api.add_route('/insight/{keyword}', ins.Resource())
api.add_route('/insights', ins.Batch())
api.add_route('/v2/insight/{keyword}', ins2.Resource())
api.add_route('/v2/insights', ins2.Batch())

if __name__ == '__main__':
    import argparse  # for parsing passed parameters through terminal

    parser = argparse.ArgumentParser()
    # either define an IP
    parser.add_argument("-ip", help="Hostname",
                        default='0.0.0.0:8000', nargs='?')
    parser.add_argument("-socket", help="Linux Socket Name",
                        default=None, nargs='?')  # or pass path of Linux's socket
    args = parser.parse_args()

    if args.socket:  # a socket is passed
        bjoern.run(wsgi_app, 'unix:' + args.socket)
    else:
        if ':' in args.ip:
            ip, separator, port = args.ip.rpartition(':')
            ip = ip_address(ip.strip("[]"))
            port = int(port)
        else:
            ip = ip_address(args.ip.strip("[]"))
            port = 8000
        ip = str(ip)
        bjoern.run(wsgi_app, ip, port)
