import Vue from 'vue'

new Vue({
  el: 'body'
})