#地址
http://116.62.167.76:5000

#接口输出结构
```
{
    "data":{},
    "pagination": {},  //count,total_count,page
    "status":  0,
    "msg": "",
}
```

#接口列表
##版本列表
###路径
GET /all_versions
###参数
无

###响应

```json
{
  "status": 0,
  "data": [
    {
      "version": "v1",
      "score_result_table": "keyword_score_v1",
      "order_fields": [
        {
          "field_key": "weight",
          "field_name": "权重"
        },
        {
          "field_key": "score",
          "field_name": "评分"
        },
        {
          "field_key": "is_core",
          "field_name": "是否核心词"
        },
        ...
      ]
    },
    {
      "version": "v2",
      "score_result_table": "keyword_score_v2",
      "order_fields": [
        {
          "field_key": "weight",
          "field_name": "权重"
        },
        {
          "field_key": "score",
          "field_name": "评分"
        },
        {
          "field_key": "is_core",
          "field_name": "是否核心词"
        },
        ...
      ]
    }
    ...
  ],
  "msg": "success",
  "pagination": {}
}
```


## 无结果词列表
###路径
POST /no_result_keywords
###参数
| name     | type   | required | desc                                     |
| -------- | ------ | -------- | ---------------------------------------- |
| version        | string    | required | 评分算法版本：v1,v2,v3...     |
| page        | int    | optional | 分页页码，从1开始                                |
| size     | int    | optional | 页面大小，默认为20                               |
| is_core | int    | required | 是否只查询核心词 1：是；0：不是 |
| is_maintain | int    | required | 是否只查询运营过的词 1：是；0：不是 |
| order_fields   | array | optional | 排序字段及排序方式的字典数组。eg:[{"order_field":"weight", "order_type":"DESC"},{"order_field":"score", "order_type":"ASC"}] 。排序字段在版本接口返回的order_fields中选择  |

###响应(各个评分版本word的数据会有不同，根据版本处理)
```json
{
  "status": 0,
  "data": {
    "words": [
      {
        "guid": "f77be49265bd11e6b8ea52545c27316d",
        "category": "\u57fa\u7840\u5173\u952e\u8bcd",
        "text": "\u5954\u8dd1",
        "weight": 1,
        "is_core": 1,
        "maintain": 1,
        "clevel": 2,
        "kind": 0,
        "score": 98.0,
        "image_count": 100,
        "anim_ratio": 0.98,
        "match_ratio": 1.0,
        "avg_size": 181780.0
      },
      ...
    ]
  },
  "msg": "success",
  "pagination": {
    "count": 2,
    "page": 1,
    "size": 2,
    "total_count": 4802
  }
}
```

##所有词列表
###路径
POST /all_keywords
###参数
| name     | type   | required | desc                                     |
| -------- | ------ | -------- | ---------------------------------------- |
| version        | string    | required | 评分算法版本：v1,v2,v3...     |
| page        | int    | optional | 分页页码，从1开始                                |
| size     | int    | optional | 页面大小，默认为20                               |
| is_core | int    | required | 是否只查询核心词 1：是；0：不是 |
| is_maintain | int    | required | 是否只查询运营过的词 1：是；0：不是 |
| order_fields   | array | optional | 排序字段及排序方式的字典数组。eg:[{"order_field":"weight", "order_type":"DESC"},{"order_field":"score", "order_type":"ASC"}] 。排序字段在版本接口返回的order_fields中选择  |


###响应(各个评分版本word的数据会有不同，根据版本处理)
```json
{
  "status": 0,
  "data": {
    "words": [
      {
        "guid": "d72f14a66b5e11e6b8ea52545c27316d",
        "category": "\u8054\u60f3\u5173\u952e\u8bcd",
        "text": "\u5728",
        "weight": 475,
        "is_core": 1,
        "maintain": 1,
        "clevel": 6,
        "kind": 0,
        "score": 87.7193,
        "image_count": 100,
        "quality_score": 0.9405,
        "anim_ratio": 0.99,
        "size_adequate_ratio": 0.95,
        "match_ratio": 1.0,
        "distribution_score": 0.475216,
        "anim_distribution_score": 0.997949,
        "size_distribution_score": 0.476192,
        "match_distribution_score": 1.0,
        "anim_distribution_detail": [
          "1",
          ...
        ],
        "size_distribution_detail": [
          1,
          ...
        ],
        "match_distribution_detail": [
          1,
          ...
        ]
      }
      ...
    ]
  },
  "msg": "success",
  "pagination": {
    "count": 2,
    "page": 1,
    "size": 2,
    "total_count": 4802
  }
}
```


## 单个词评分结果
###路径
POST /single_word
###参数
| name     | type   | required | desc                                     |
| -------- | ------ | -------- | ---------------------------------------- |
| version        | string    | required | 评分算法版本：v1,v2,v3...     |
| word        | string    | required | 要查看的词     |

###响应(各个评分版本word的数据会有不同，根据版本处理)
```json
{
  "status": 0,
  "data": {
    "word": {
      "guid": "",
      "category": "",
      ...
    },
    "in_db": 0 //标识查询的词是否已经统一评分后存储在数据库中。
  },
  "msg": "success",
  "pagination": {}
}
```