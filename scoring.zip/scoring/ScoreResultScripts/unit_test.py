#!/usr/bin/env python3
# coding:utf-8
from db_io import DBManager
import json
from urllib import request, parse
from models import *
db = DBManager()

def test_no_result_core_keywords():
    version = KeywordScoreVersion("v2")
    words, totalCount = db.no_result_keywords(version,size=4, is_maintain=False, weight_order=orderType.NONE)
    print(words)
    words, totalCount = db.no_result_keywords(version,size=4, is_maintain=False, weight_order=orderType.DESC)
    print(words)
    words, totalCount = db.no_result_keywords(version,size=4, is_maintain=False, weight_order=orderType.ASC)
    print(words)
    
    # for word in words:
    #     print(word)

def test_all_keywords():
    version = KeywordScoreVersion("v1")
    db.all_keywords(version,size=4, score_order=orderType.DESC)
    words1, totalCount = db.all_keywords(version,size=4, score_order=orderType.DESC)
    print(totalCount)
#     words = db.all_keywords(version,size=4, is_maintain=False, score_order=orderType.NONE, weight_order=orderType.ASC)
#     for word in words:
#         print(word)

# test_all_keywords()
# test_no_result_core_keywords()

# if orderType("ASC"):
# 	print("ASC")
# try:
# 	order = orderType("asc")
# except (Exception) as e:
# 	print(e)


# params = {"one":1, "two":2}
# if 'one' in params:
# 	print("yes")
# else:
# 	print("no")


# print(KeywordScoreVersion("v1") is None)
# print(KeywordScoreVersion("V1") is None)
# print(KeywordScoreVersion("v3"))

order_fields = get_order_fields_with_version("v1")
print(order_fields)
for o in order_fields:
    if "weigh" in o.values():
        print("ddd")
