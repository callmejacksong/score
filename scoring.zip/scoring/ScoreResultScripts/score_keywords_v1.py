#!/usr/bin/env python3
# coding:utf-8

##说明
##评分算法V1
##keyword_net表里maintain=1的词
##exist_result_keyword所有的词
from db_io import DBManager, resolve_score_result_from_score_api_with_version
import json
from urllib import request, parse
import requests
db = DBManager()
offset = 0
leftCount = 1
# try:
#     while(leftCount > 0):
#         # keywords = db.get_keywords(offset) ##keyword_net表里maintain=1的词
#         keywords = db.get_keywords_from_exist_result_keywords(offset)
#         leftCount = len(keywords)
#         offset = offset + len(keywords)
#         textArray = [data[2] for data in keywords]
#         url = "http://121.196.194.171:8000/insights?" + parse.quote(json.dumps(textArray))
#         print(url)
#         req = request.Request(url)
#         with request.urlopen(req) as f:
#             result = f.read().decode("utf-8")
#             result = json.loads(result)
#             insertDatas = []
#             for data in keywords:
#                 score = 0.0
#                 score_des = ""
#                 try:
#                     re = result[data[2]]
#                     score_des = json.dumps(re)
#                     score = re["score"]["value"]
#                 except Exception as e:
#                     print(data[2], ": 无搜索结果")
#                 insertData = data + (score, score_des)
#                 insertDatas.append(insertData)
#             db.insert_scored_keywords(insertDatas)
#             db.commit()
#         print("offset:", offset)
# except Exception as e:
#     print(e)
#     db.rollback()

keywords = db.get_keywords(offset)##keyword_net表里maintain=1的词
count = 0
insert_data=[]
for word_info in keywords:
    url = "http://localhost:8000/insight/"+word_info[2]
    try:
        r = requests.get(url, timeout=9000)
        results = json.loads(r.text)
    except:
        results = []
    for result in results:
        resolvedData = resolve_score_result_from_score_api_with_version("v1", word_info, result)
        resolvedData = list(resolvedData)
        resolvedData[0] = resolvedData[0] + str(result.get("search_type", ""))
        resolvedData = tuple(resolvedData)
        insert_data.append(resolvedData)
    count += 1
    if count % 10 == 0:
        db.insert_scored_keywords(insert_data)
        db.commit()
        insert_data = []
    try:
        print("进行到 " + str(count))
        print(word_info[2])
    except:
        pass


