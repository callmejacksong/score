#!/usr/bin/env python3
# coding:utf-8

##说明
##评分算法V2
##keyword_net表里maintain=1 or is_core=1的词
##exist_result_keyword所有的词

##算法意见
##尺寸的长宽也分别列入尺寸相关的评分
import requests

from db_io import DBManager
import json
from urllib import request, parse

from models import resolve_score_result_from_score_api_with_version

db = DBManager()
offset = 0
leftCount = 1
# try:
#     while(leftCount > 0):
#         # keywords = db.get_keywords(offset) ##keyword_net表里maintain=1 or is_core = 1的词
#         keywords = db.get_keywords_from_exist_result_keywords(offset)
#         leftCount = len(keywords)
#         offset = offset + len(keywords)
#         textArray = [data[2] for data in keywords]
#         url = "http://116.62.167.76:8000/v2/insights?" + parse.quote(json.dumps(textArray))
#         req = request.Request(url)
#         with request.urlopen(req) as f:
#             result = f.read().decode("utf-8")
#             result = json.loads(result)
#             insertDatas = []
#             for data in keywords:
#                 score = 0.0
#                 image_count = 0
#                 quality_score = 0.0
#                 anim_ratio = 0.0
#                 size_adequate_ratio = 0.0
#                 match_ratio = 0.0
#                 distribution_score = 0.0
#                 anim_distribution_detail = ""
#                 anim_distribution_score = 0.0
#                 size_distribution_detail = ""
#                 size_distribution_score = 0.0
#                 match_distribution_detail = ""
#                 match_distribution_score = 0.0
#                 meta_data = ""
#                 try:
#                     re = result[data[2]]
#                     score = str(re["score"]["value"])
#                     image_count = str(re["attr"]["quantity"]["count"]["value"])
#                     quality_score = str(re["attr"]["quality"]["score"])
#                     anim_ratio = str(re["attr"]["quality"]["anim_ratio"]["score"])
#                     size_adequate_ratio = str(re["attr"]["quality"]["size_adequate_ratio"]["score"])
#                     match_ratio = str(re["attr"]["quality"]["match_ratio"]["score"])
#                     distribution_score = str(re["attr"]["distribution"]["score"])
#                     anim_distribution_detail = json.dumps(re["attr"]["distribution"]["anim_detail"]["value"])
#                     anim_distribution_score = str(re["attr"]["distribution"]["anim_detail"]["score"])
#                     size_distribution_detail = json.dumps(re["attr"]["distribution"]["size_detail"]["value"])
#                     size_distribution_score = str(re["attr"]["distribution"]["size_detail"]["score"])
#                     match_distribution_detail = json.dumps(re["attr"]["distribution"]["match_detail"]["value"])
#                     match_distribution_score = str(re["attr"]["distribution"]["match_detail"]["score"])
#                     meta_data = json.dumps(re["attr"]["meta_data"])
#                 except Exception as e:
#                     print(data[2], ": 无搜索结果")
#                 insertData = data + (score, image_count, quality_score, anim_ratio, size_adequate_ratio,
#                 match_ratio, distribution_score, anim_distribution_detail, anim_distribution_score, size_distribution_detail,
#                 size_distribution_score, match_distribution_detail, match_distribution_score, meta_data)
#                 insertDatas.append(insertData)
#             db.insert_scored_keywords_v2(insertDatas)
#             db.commit()
#         print("offset:", offset)
# except Exception as e:
#     print(e)
#     db.rollback()


keywords = db.get_keywords(offset)##keyword_net表里maintain=1的词
count = 0
insert_data=[]
for word_info in keywords:
    url = "http://localhost:8000/v2/insight/"+word_info[2]
    try:
        r = requests.get(url, timeout=9000)
        results = json.loads(r.text)
    except:
        results=[]
    for result in results:
        resolvedData = resolve_score_result_from_score_api_with_version("v2", word_info, result)
        resolvedData = list(resolvedData)
        resolvedData[0] = resolvedData[0] + str(result.get("search_type", ""))
        resolvedData = tuple(resolvedData)
        insert_data.append(resolvedData)
    count += 1
    if count % 10 == 0:
        db.insert_scored_keywords_v2(insert_data)
        db.commit()
        insert_data = []
    try:
        print("进行到 " + str(count))
        print(word_info[2])
    except:
        pass