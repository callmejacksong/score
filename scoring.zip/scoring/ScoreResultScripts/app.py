# -*- coding:utf-8 -*-
# !flask/bin/python
import json
import os
import sys
from datetime import datetime
from flask import Flask, request, redirect, url_for, send_from_directory
from flask_cors import CORS
from flask_bootstrap import Bootstrap
from db_io import DBManager
from models import *
import helper
app = Flask(__name__)
# CORS(app, resources=r'/*')
CORS(app, supports_credentials=True)
bootstrap = Bootstrap(app)

db = DBManager()

def construct_result(re, message="ok", data={}, pagination={}):
    reDic = {}
    if re:
        reDic['status'] = 0
        reDic['data'] = data
        reDic['msg'] = "success"
        reDic['pagination'] = pagination
    else:
        reDic['status'] = -1
        reDic['msg'] = message
    return json.dumps(reDic,ensure_ascii=False)


@app.route('/all_versions', methods=['GET'])
def all_versions():
    all_versions = []
    for version in all_keyword_score_versions:
        v = KeywordScoreVersion(version)
        all_versions.append(v.get_version_instance())
    return construct_result(True, data=all_versions)

@app.route('/no_result_keywords', methods=['POST'])
def no_result_keywords():
    try:
        params = request.values
        ##required
        version = KeywordScoreVersion(params['version'])
        is_maintain = True if int(params['is_maintain']) == 1 else False
        is_core = True if int(params['is_core']) == 1 else False
        ##optional 
        order_fields = []
        if "order_fields" in params:
            order_fields_array = json.loads(params['order_fields'])
            for order in order_fields_array:
                order_field = order['order_field']
                order_type = order['order_type'].upper()
                for o in version.orderFields:
                    if order_field in o.values():
                        order_fields.append((order_field,orderType(order_type)))
                        break
        page = 1
        size = 50
        if 'size' in params:
            size = int(params['size'])
        if 'page' in params:
            page = int(params['page'])
        
        db1 = DBManager()
        words, total_count = db1.no_result_keywords(version, size=size, page=page, is_core=is_core, is_maintain=is_maintain, order_fields=order_fields)
        data = {"words": words}
        pagination = {"count":len(words), "page": page, "size": size, "total_count": total_count}
        return construct_result(True, "OK", data, pagination)
    except (Exception) as e:
        print(type(e))
        print(e.args)
        return construct_result(False, json.dumps(e.args[0]))

@app.route('/all_keywords', methods=['POST'])
def all_keywords():
    try:
        params = request.values
        ##required
        version = KeywordScoreVersion(params['version'])
        is_maintain = True if int(params['is_maintain']) == 1 else False
        is_core = True if int(params['is_core']) == 1 else False

        ##optional 
        order_fields = []
        if "order_fields" in params:
            order_fields_array = json.loads(params['order_fields'])
            for order in order_fields_array:
                order_field = order['order_field']
                order_type = order['order_type'].upper()
                for o in version.orderFields:
                    if order_field in o.values():
                        order_fields.append((order_field,orderType(order_type)))
                        break
        
        page = 1
        size = 50
        if 'size' in params:
            size = int(params['size'])
        if 'page' in params:
            page = int(params['page'])
        
        db1 = DBManager()
        words, total_count = db1.all_keywords(version, size=size, page=page, is_core=is_core, is_maintain=is_maintain, order_fields=order_fields)
        data = {"words": words}
        pagination = {"count":len(words), "page": page, "size": size, "total_count": total_count}
        return construct_result(True, "OK", data, pagination)
    except (Exception) as e:
        print(type(e))
        print(e.args)
        return construct_result(False, json.dumps(e.args[0]))

@app.route('/single_word', methods=['POST','GET'])
def single_word():
    try:
        params = request.values
        ##required
        version = KeywordScoreVersion(params['version'])
        word = params['word']
        db1 = DBManager()
        re = helper.get_single_word_score_result_with_version(db1, word, version)
        db1.commit()
        return construct_result(True, data=re)
    except (Exception) as e:
        print(type(e))
        print(e.args)
        db1.rollback()
        return construct_result(False, json.dumps(e.args[0]))
    

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
