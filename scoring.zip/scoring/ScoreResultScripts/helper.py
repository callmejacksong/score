#!/usr/bin/env python3
# coding:utf-8
import json
import uuid
from urllib import request, parse
from models import *
import string

# from db_io import DBManager
def get_uuid():
    tem_str = str(uuid.uuid1())
    uuid_str = "".join(tem_str.split("-"))
    return uuid_str

def get_single_word_score_result_with_version(db, word, version):
    res = db.get_single_word_score_result(version, word)
    if len(res) >= 1:
        return {"word": res, "in_db": 1}
    url = version.score_base_api + "/insight/" + word
    url = parse.quote(url, safe = string.printable)
    
    req = request.Request(url)
    with request.urlopen(req) as f:
        results = f.read().decode("utf-8")
        results = json.loads(results)
        result_list=[]
        for result in results:
            data = ("", "", word, -1, -1, -1, -1, -1)
            resolvedData = resolve_score_result_from_score_api_with_version(version.version, data, result)
            res = version.get_keyword_instance(resolvedData)
            result_list.append(res)
        # 将存在表中的关键字插入到数据库中
        word_info = db.get_keyword_info(word)
        if len(word_info)>0 and len(result_list)>0:
            insert_data = []
            for result in results:
                resolvedData = resolve_score_result_from_score_api_with_version(version.version, word_info, result)
                resolvedData = list(resolvedData)
                resolvedData[0] = resolvedData[0] + str(result.get("search_type",""))
                resolvedData = tuple(resolvedData)
                insert_data.append(resolvedData)

            if version.version=="v1":
                db.insert_scored_keywords(insert_data)
            elif version.version=="v2":
                db.insert_scored_keywords_v2(insert_data)

        return {"word": result_list, "in_db": 0}


    






# version = KeywordScoreVersion('v2')
# res = get_single_word_score_result_with_version("哈", version)
# print(res)
import threading as tr
# from db import DB


# testdb = DB("rm-bp1664spovq6woabo7o.mysql.rds.aliyuncs.com", "ori", "Aa123456", "experiment")
# testdb.get_con()
# def test1():
#     print("=========test1========")
#     cursor = testdb.get_cursor()
#     print(cursor)
#     cursor.execute("select count(*) from test")
#     countRes = cursor.fetchall()
#     print(countRes)
#
# def test2():
#     print("=========test2========")
#     cursor = testdb.get_cursor()
#     print(cursor)
#     cursor.execute("select count(*) from test")
#     countRes = cursor.fetchall()
#     print(countRes)
#
# # def test():
# #     testdb.get_cursor().execute("select count(*) from keyword_score_v1")
# #     testdb.get_cursor().execute("select count(*) from keyword_score_v2")
# #     countRes1 = testdb.get_cursor().fetchall()
# #     print(countRes1)
# #     countRes2 = testdb.get_cursor().fetchall()
# #     print(countRes2)
#
#
# test1()
# test2()
#


# thread1 = tr.Thread(target = test1)
# thread2 = tr.Thread(target = test2)
# thread1.start()
# thread2.start()
# thread1.join()
# thread2.join()


# test()