#!/usr/bin/env python3
# coding:utf-8
##简单的正态分布
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from db_io import DBManager
import json
from urllib import request, parse
db = DBManager()

plt.rcParams['font.sans-serif']=['SimHei']

scores = db.all_keyword_with_result_score()
data = np.array(scores).astype(np.float64)

mean = float(data.mean())
std = float(data.std())
minX = math.floor(data.min())
maxX = math.ceil(data.max())
print(minX, maxX)
x = np.arange(minX,maxX,1) 
y = stats.norm.pdf(x, mean, std)

plt.figure(figsize=(9,6))
plt.title(u'{} keywords with results'.format(str(len(scores))))
plt.plot(x,y)
plt.show()

