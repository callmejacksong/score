#!/usr/bin/env python3
# coding:utf-8
from db_io import DBManager
import json

#将之前评分详细信息提取成字段
#135355

db = DBManager()

offset = 0
leftCount = 1
try:
    while(leftCount > 0):
        results = db.get_unextract_results(offset)
        leftCount = len(results)
        offset = offset + len(results)
        attrTupleArr = []
        for re in results:
            guid, des = re
            print(guid)
            desDic = json.loads(des)
            image_count = desDic["attr"]["count"]["value"]
            anim_ratio = desDic["attr"]["anim_ratio"]["value"]
            match_ratio = desDic["attr"]["match_ratio"]["value"]
            avg_size = desDic["attr"]["avg_size"]["value"]
            attrTupleArr.append((str(image_count), str(anim_ratio), str(match_ratio), str(avg_size), str(guid)))
        if len(attrTupleArr) > 0:
            db.update_keyword_result_attr(attrTupleArr)
            db.commit()
        # leftCount = 0
        print("offset:", offset)
except Exception as e:
    print(e)
    db.rollback()