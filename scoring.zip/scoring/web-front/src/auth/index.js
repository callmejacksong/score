import Cookie from './Cookie';

export default Cookie;
