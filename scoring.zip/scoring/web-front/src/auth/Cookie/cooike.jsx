import Cookies from 'js-cookie';

export default new class Cookie {
  /**
   * 构造函数
   */
  constructor() {
    this.defaults = {};
    this.prefix = 'dt_';
  }


  signin = (cb, user) => {
    const key = `${this.prefix}user`;
    Cookies.set(key, user, { expires: 1 });
    setTimeout(cb, 100);
  };

  authenticate = () => {
    const user = Cookies.get(`${this.prefix}user`);
    return user;
  };

  signout = (cb) => {
    const key = `${this.prefix}user`;
    Cookies.remove(key);
    setTimeout(cb, 100);
  };
};
