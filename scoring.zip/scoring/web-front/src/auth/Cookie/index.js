import Cookie from './cooike';

export default Cookie;
