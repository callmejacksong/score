import React, { Component } from 'react';
let getBlock = (arr) => {
  try {
    return (
      <div style={styles.container}>
        {arr.map((value, index) => { return <div key={index} style={value == 1 ? styles.bgGreen : styles.bgRed}></div> })}
      </div>
    )
  } catch (e) { }
}
let columnsDict = {
  v1: [
    {
      title: '内容',
      dataIndex: 'text',
      width: 100
    },
    {
      title: '权重',
      dataIndex: 'weight',
      width: 100
    },
    {
      title: '是否核心词',
      dataIndex: 'is_core',
      width: 100,
      cell(value) {
        return value == 1 ? '是' : '否'
      }
    },
    {
      title: '是否运营过',
      dataIndex: 'maintain',
      width: 100,
      cell(value) {
        return value == 1 ? '是' : '否'
      }
    },
    {
      title: '评分',
      dataIndex: 'score',
      width: 100,
    },
    {
      title: '图片数量',
      dataIndex: 'image_count',
      width: 100,
    },
    {
      title: '动图占比',
      dataIndex: 'anim_ratio',
      width: 100,
    },
    {
      title: '关键词匹配占比',
      dataIndex: 'match_ratio',
      width: 100,
    },
    {
      title: '图片平均尺寸',
      dataIndex: 'avg_size',
      width: 100,
    },
  ],
  v2: [
    {
      title: '内容',
      dataIndex: 'text',
      width: 100
    },
    {
      title: '权重',
      dataIndex: 'weight',
      width: 100
    },
    {
      title: '是否核心词',
      dataIndex: 'is_core',
      width: 100,
      cell(value) {
        return value == 1 ? '是' : '否'
      }
    },
    {
      title: '是否运营过',
      dataIndex: 'maintain',
      width: 100,
      cell(value) {
        return value == 1 ? '是' : '否'
      }
    },
    {
      title: '评分',
      dataIndex: 'score',
      width: 100,
    },
    {
      title: '搜索到的图片数量',
      dataIndex: 'image_count',
      width: 100,
    },
    {
      title: '质量评分',
      dataIndex: 'quality_score',
      width: 100,
    },
    {
      title: '动图占比',
      dataIndex: 'anim_ratio',
      width: 100,
    },
    {
      title: '清晰度合适的图片占比',
      dataIndex: 'size_adequate_ratio',
      width: 100,
    },
    {
      title: '关键词的图片占比',
      dataIndex: 'match_ratio',
      width: 100,
    },
    {
      title: '分布评分',
      dataIndex: 'distribution_score',
      width: 100,
    },
    {
      title: '动图分布情况评分',
      dataIndex: 'anim_distribution_score',
      width: 100,
    },
    {
      title: '清晰度分布情况评分',
      dataIndex: 'size_distribution_score',
      width: 100,
    },
    {
      title: '关键词的图片分布情况评分',
      dataIndex: 'match_distribution_score',
      width: 100,
    },
    {
      title: '动图分布详情',
      dataIndex: 'anim_distribution_detail',
      width: 100,
      cell: getBlock
    },
    {
      title: '清晰度分布详情',
      dataIndex: 'size_distribution_detail',
      width: 100,
      cell: getBlock
    },
    {
      title: '关键词的图片分布详情',
      dataIndex: 'match_distribution_detail',
      width: 100,
      cell: getBlock
    },
  ],
  all: [
    {
      title: '内容',
      dataIndex: 'text',
      width: 100
    },
    {
      title: '权重',
      dataIndex: 'weight',
      width: 100
    },
    {
      title: '是否核心词',
      dataIndex: 'is_core',
      width: 100,
      cell(value) {
        return value == 1 ? '是' : '否'
      }
    },
    {
      title: '是否运营过',
      dataIndex: 'maintain',
      width: 100,
      cell(value) {
        return value == 1 ? '是' : '否'
      }
    },
    {
      title: '评分',
      dataIndex: 'score',
      width: 100,
    },
    {
      title: '搜索到的图片数量',
      dataIndex: 'image_count',
      width: 100,
    },
    {
      title: '质量评分',
      dataIndex: 'quality_score',
      width: 100,
    },
    {
      title: '动图占比',
      dataIndex: 'anim_ratio',
      width: 100,
    },
    {
      title: '清晰度合适的图片占比',
      dataIndex: 'size_adequate_ratio',
      width: 100,
    },
    {
      title: '关键词的图片占比',
      dataIndex: 'match_ratio',
      width: 100,
    },
    {
      title: '分布评分',
      dataIndex: 'distribution_score',
      width: 100,
    },
    {
      title: '动图分布情况评分',
      dataIndex: 'anim_distribution_score',
      width: 100,
    },
    {
      title: '清晰度分布情况评分',
      dataIndex: 'size_distribution_score',
      width: 100,
    },
    {
      title: '关键词的图片分布情况评分',
      dataIndex: 'match_distribution_score',
      width: 100,
    },
    {
      title: '动图分布详情',
      dataIndex: 'anim_distribution_detail',
      width: 100,
      cell: getBlock
    },
    {
      title: '清晰度分布详情',
      dataIndex: 'size_distribution_detail',
      width: 100,
      cell: getBlock
    },
    {
      title: '关键词的图片分布详情',
      dataIndex: 'match_distribution_detail',
      width: 100,
      cell: getBlock
    },
    {
      title: '图片平均尺寸',
      dataIndex: 'avg_size',
      width: 100,
    },
  ]
}
let cvsDict = {
  "v1": {
    "arrKey": [
      "text",
      "weight",
      "is_core",
      "maintain",
      "score",
      "image_count",
      "anim_ratio",
      "match_ratio",
      "avg_size"
    ],
    "arrTitle": [
      "内容",
      "权重",
      "是否核心词",
      "是否运营过",
      "评分",
      "图片数量",
      "动图占比",
      "关键词匹配占比",
      "图片平均尺寸"
    ]
  },
  "v2": {
    "arrKey": [
      "text",
      "weight",
      "is_core",
      "maintain",
      "score",
      "image_count",
      "quality_score",
      "anim_ratio",
      "size_adequate_ratio",
      "match_ratio",
      "distribution_score",
      "anim_distribution_score",
      "size_distribution_score",
      "match_distribution_score",
    ],
    "arrTitle": [
      "内容",
      "权重",
      "是否核心词",
      "是否运营过",
      "评分",
      "搜索到的图片数量",
      "质量评分",
      "动图占比",
      "清晰度合适的图片占比",
      "关键词的图片占比",
      "分布评分",
      "动图分布情况评分",
      "清晰度分布情况评分",
      "关键词的图片分布情况评分",
    ]
  },
  all: {
    "arrKey": [
      "text",
      "weight",
      "is_core",
      "maintain",
      "score",
      "image_count",
      "quality_score",
      "anim_ratio",
      "size_adequate_ratio",
      "match_ratio",
      "distribution_score",
      "anim_distribution_score",
      "size_distribution_score",
      "match_distribution_score",
      "avg_size"
    ],
    "arrTitle": [
      "内容",
      "权重",
      "是否核心词",
      "是否运营过",
      "评分",
      "搜索到的图片数量",
      "质量评分",
      "动图占比",
      "清晰度合适的图片占比",
      "关键词的图片占比",
      "分布评分",
      "动图分布情况评分",
      "清晰度分布情况评分",
      "关键词的图片分布情况评分",
      "图片平均尺寸"
    ]
  }
}
let styles = {
  container: {
    width: 100,
    height: 100
  },
  bgRed: {
    float: 'left',
    background: 'red',
    width: 10,
    height: 10
  },
  bgGreen: {
    float: 'left',
    background: 'green',
    width: 10,
    height: 10
  }
}
export default { columnsDict, cvsDict }