
import axios from 'axios';
import qs from 'qs'
import { Feedback } from '@icedesign/base';

const DOMIN = 'http://116.62.167.76:5000/'
// const DOMIN = 'http://192.168.17.174:5000/'

let _httpError = () => {
    Feedback.toast.error('网络错误');
}

let callHttp = (opt) => {
    let data = opt.data || {}
    let method = opt.method || 'get'
    let headers = opt.headers || { 'Content-type': 'application/x-www-form-urlencoded' }

    let url = opt.url
    if (!/http:\/\//.test(opt.url)) {
        url = DOMIN + opt.url
    }
    let option = { method, headers, url, data }
    if (opt.method == 'get') {
        option.params = data
    } else {
        option.data = qs.stringify(data)
    }
    return new Promise((resolve, reject) => {
        axios(option).then((res) => {
            let data = res.data
            if (data.status == 0) {
                resolve(data)
            } else {
                reject()
                _httpError()
            }
        }).catch((data) => {
            reject()
            _httpError()
        })
    })
}

let exportCSV = (arr, dict) => {
    try {
        let data = [dict.arrTitle]
        let keys = dict.arrKey
        for (let i = 0; i < arr.length; i++) {
            let subArr = []
            for (let j = 0; j < keys.length; j++) {
                let text = arr[i][keys[j]]
                if (keys[j] == 'maintain' || keys[j] == 'is_core') {
                    text = text == 1 ? '是' : '否'
                }
                subArr.push(text)
            }
            data.push(subArr)
        }

        if(!arr.length){
            Feedback.toast.prompt('请查询数据');
            return
        }

        function processRow(row) {
            let finalVal = '';
            for (let j = 0; j < row.length; j++) {
                let innerValue = row[j] === undefined ? '' : row[j].toString();
                let result = innerValue.replace(/"/g, '""');
                if (result.search(/("|,|\n)/g) >= 0)
                    result = '"' + result + '"';
                if (j > 0)
                    finalVal += ',';
                finalVal += result;
            }
            return finalVal;
        };

        let csvString = data.map(function (item) { return processRow(item) }).join("\n");

        //前置的"\uFEFF"为“零宽不换行空格”，可处理中文乱码问题
        let blob = new Blob(["\uFEFF" + csvString], { type: 'text/csv;charset=gb2312;' });

        let a = document.createElement('a');
        a.download = 'score.csv';//这里替换为你需要的文件名
        a.href = URL.createObjectURL(blob);
        a.click();
    } catch (e) { }
}


//键盘点击ENTERE
function keyEnter(fn) {
    document.onkeydown = (e) => {
        let a = e || window.event;
        if (a.keyCode == 13) {
            fn()
        }
    }
}

//克隆对象
function clone(obj) {
    let o;
    if (typeof obj == "object") {
        if (obj === null) {
            o = null;
        } else {
            if (obj instanceof Array) {
                o = [];
                for (let i = 0, len = obj.length; i < len; i++) {
                    o.push(clone(obj[i]));
                }
            } else {
                o = {};
                for (let j in obj) {
                    o[j] = clone(obj[j]);
                }
            }
        }
    } else {
        o = obj;
    }
    return o;
}

let all_versions_data
let getVersion = (success=()=>{},fail=()=>{}) => {
    if (all_versions_data) {
        success(all_versions_data)
    } else {
        callHttp({ url: 'all_versions' })
            .then((res) => {
                success(res)
                all_versions_data = res
            })
            .catch(fail)
    }
}


export default { callHttp, exportCSV, keyEnter, clone, getVersion }