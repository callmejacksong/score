import React, { Component } from 'react';
import {Loading} from "@icedesign/base";

export default class Loadding extends Component {
    render() {
        return (
            <div>
                {this.props.visible ? <Loading style={styles.loadding} shape="fusion-reactor"></Loading> : ''}
            </div>
        )
    }
}

const styles = {
  loadding: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    background: 'rgba(0,0,0,0.5)',
    zIndex: 1000
  },
}