import React, { Component } from 'react';
import { Input, Button, Checkbox, Feedback } from "@icedesign/base";
import IceContainer from '@icedesign/container';
import util from '../../utils/util'
import CustomTable from '../../components/CustomTable'
import Loadding from '../../components/Loadding'

const { Group: CheckboxGroup } = Checkbox;

import publicObj from '../../utils/publicObj.jsx'

export default class WordAlone extends Component {

  constructor(props) {
    super(props);
    this.data = {
      wordValue: '',
      versionVals: []
    }
    this.state = {
      tableData: [],
      visible: true
    }
  }

  componentWillMount() {
    this.columns = util.clone(publicObj.columnsDict.all)
    this.columns.unshift({
      title: '操作',
      cell: (e, index) => {
        return <Button shape="warning" onClick={this.remove.bind(this, index)}>删除</Button>
      },
      width: 100,
    })

    util.getVersion((res) => {
      let { data } = res
      let versionDataSource = []
      for (let i = 0; i < data.length; i++) {
        let version = data[i].version
        versionDataSource.push({
          value: version,
          label: version,
        })
      }
      this.setState({ versionDataSource, visible: false })
    }, () => {
      this.setState({ visible: false })
    })

    document.onkeydown = (e) => {
      let a = e || window.event;
      if (a.keyCode == 13) {
        this.confirm()
      }
    }
  }

  onInput = (wordValue) => {
    this.data.wordValue = wordValue.trim()
  }

  remove(index) {
    let tableData = this.state.tableData;
    tableData.splice(index, 1);
    this.setState({
      tableData
    })
  }

  exportCSV = () => {
    util.exportCSV(this.state.tableData, publicObj.cvsDict.all)
  }

  versionRadioChange = (value) => {
    this.data.versionVals = value
  }

  confirm = () => {
    let { wordValue, versionVals } = this.data
    if (!wordValue) {
      Feedback.toast.prompt('请输入关键字！')
    } else if (!versionVals.length) {
      Feedback.toast.prompt('请选则版本！')
    } else {
      for (let i = 0; i < versionVals.length; i++) {
        this.getData({ version: versionVals[i], word: wordValue })
      }
    }
  }

  getData = (data) => {
    this.setState({ visible: true })
    util.callHttp({ url: 'single_word', data, method: 'post' })
      .then((res) => {
        let data = res.data
        let tableData = this.state.tableData.concat(data.word);
        this.setState({
          tableData: tableData
        })
        this.setState({ visible: false })
      })
      .catch(()=>{
        this.setState({ visible: false })
      })
  }

  render() {
    return (
      <div style={styles.wrapper}>
        <Loadding visible={this.state.visible} />
        <IceContainer title="操作">
          <label>版本：</label>
          <CheckboxGroup onChange={this.versionRadioChange} dataSource={this.state.versionDataSource} />
          <label style={styles.ml30}>关键词：</label>
          <Input size="large" onChange={this.onInput} placeholder="请输入评分词" />
          <Button type="primary" style={styles.ml30} onClick={this.confirm}>确认</Button>
          <Button onClick={this.exportCSV} type="primary" style={styles.ml30}>导出csv</Button>
        </IceContainer>
        <IceContainer title="结果">
          <CustomTable
            dataSource={this.state.tableData}
            columns={this.columns}
            hasBorder={false}
          />
        </IceContainer>
      </div>
    );
  }
}
const styles = {
  ml30: {
    marginLeft: 30
  },
  wrapper: {
    position: 'relative'
  },
}