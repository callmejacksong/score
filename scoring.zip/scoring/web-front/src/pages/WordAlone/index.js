import WordAlone from './WordAlone';

export default WordAlone;
