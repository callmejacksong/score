import React, { Component } from 'react';
import LoginC from './components/Login';

export default class Login extends Component {
  static displayName = 'Login';

  constructor(props) {
    console.log(props)
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="login-page">
        <LoginC location={this.props.location} />
      </div>
    );
  }
}
