import React, { Component } from 'react';
import { Radio, Checkbox } from "@icedesign/base";
import { FormBinder } from '@icedesign/form-binder';

const { Group: RadioGroup } = Radio;
const { Group: CheckboxGroup } = Checkbox;

export default class Group extends Component {
    getGroup = ()=> {
        var groups = this.props.groups
        return groups.map((item, index) => {
            let { label, name, dataSource, tagName, onChange } = item
            return (
                <div style={styles.formItem} key={index}>
                    <span style={styles.formItemLabel}>{label}：</span>
                    <FormBinder name={name}>
                        {tagName == 'RadioGroup' ?
                            <RadioGroup onChange={onChange} dataSource={dataSource} /> :
                            <CheckboxGroup style={styles.itemCheckboxGroup} onChange={onChange} dataSource={dataSource} />}
                    </FormBinder>
                </div>
            )
        })
    }

    render() {
        return (
            <div>
                {this.getGroup()}
            </div>
        )
    }
}

const styles = {
    formItem: {
        display: 'flex',
        alignItems: 'center',
        marginBottom: '20px'
    },
    formItemLabel: {
        width: '100px'
    },
    itemCheckboxGroup: {
        display: 'flex',
        flexWrap: 'wrap'
    },
}