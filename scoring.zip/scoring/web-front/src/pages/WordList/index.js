import WordList from './WordList';

export default WordList;
