import React, { Component } from 'react';
import { Button, Radio, Checkbox, Pagination } from "@icedesign/base";
import IceContainer from '@icedesign/container';
import { FormBinderWrapper, FormBinder } from '@icedesign/form-binder';
import CustomTable from '../../components/CustomTable'
import Loadding from '../../components/Loadding'
import util from '../../utils/util'
import Group from './Group'

const { Group: RadioGroup } = Radio;
const { Group: CheckboxGroup } = Checkbox;

import publicObj from '../../utils/publicObj.jsx'

let columnsDict = util.clone(publicObj.columnsDict)

export default class WordList extends Component {

  constructor(props) {
    super(props);
    this.state = {
      value: {
        path: 'all_keywords',
        order: [],
        field: [],
        is_core: [],
        is_maintain: []
      },
      visible: true,
      tableData: [],
      page: 1,
      total: 0
    };
    this.data = {
      interfaceDataSource: [
        { label: '所有词列表', value: 'all_keywords' },
        { label: '无结果词列表', value: 'no_result_keywords' },
      ],
      versionDataSource: [],
      orderDataSource: [
        { label: '升序', value: 'ASC' },
        { label: '降序', value: 'DESC' },
      ],
      isCoreDataSource: [
        { label: '是', value: 1 },
      ],
      isMaintainDataSource: [
        { label: '是', value: 1 },
      ],
      fieldsDict: {}
    }
  }

  componentWillMount() {
    util.getVersion((res) => {
      let { data } = res
      let arr = []
      let dict = {}
      let orderDict = {}
      let { fieldsDict } = this.data
      for (let i = 0; i < data.length; i++) {
        let version = data[i].version
        arr.push({
          value: version,
          label: version,
        })
        let subArr = dict[version] = []
        let subOrderArr = orderDict[version] = []
        for (let j = 0; j < data[i].order_fields.length; j++) {
          let { field_key, field_name } = data[i].order_fields[j]
          subArr.push({
            value: field_key,
            label: field_name,
          })
          subOrderArr.push({
            value: field_key,
            label: field_name,
          })
          fieldsDict[field_key] = field_name
        }
      }
      let value = this.state.value
      value.version = arr[0].value
      this.setState({
        versionDataSource: arr,
        value,
        fieldDataSource: dict,
        visible: false,
        orderDataSource: orderDict
      })
    }, () => {
      this.setState({
        visible: false,
      })
    })
    util.keyEnter(this.query)
  }

  formChange = (value) => {
    this.setState({ value })
  }

  versionRadioChange = () => {
    let value = this.state.value
    value.field = value.order = []
    this.setState({ value, tableData: [] })
  }

  pageChange = (page) => {
    this.setState({
      page
    }, () => {
      this.query()
    })
  }

  exportCSV = () => {
    util.exportCSV(this.state.tableData, publicObj.cvsDict[this.state.value.version])
  }

  query = () => {
    this.setState({ visible: true })

    let { version, is_core, is_maintain, path, field, order } = this.state.value
    is_core = is_core.length ? 1 : 0
    is_maintain = is_maintain.length ? 1 : 0
    let page = this.state.page
    let size = 50
    let data = { version, is_core, is_maintain, page, size }
    if (field.length) {
      let order_fields = []
      for (let i = 0; i < field.length; i++) {
        let item = field[i]
        order_fields.push({
          order_field: item,
          order_type: order.indexOf(item) != -1 ? 'ASC' : 'DESC'
        })
      }
      data.order_fields = JSON.stringify(order_fields.reverse())
    }

    util.callHttp({ url: path, method: 'POST', data, })
      .then((res) => {
        this.setState({
          visible: false,
          tableData: res.data.words,
          total: res.pagination.total_count
        })
      })
      .catch(() => {
        this.setState({ visible: false })
      })
  }

  getGroups = () => {
    let fieldDataSourch = []
    let orderDataSource = []
    try{
      fieldDataSourch = this.state.fieldDataSource[this.state.value.version]
    }catch(e){}
    if(this.state.value.field.length){
      orderDataSource = this.state.orderDataSource[this.state.value.version]
    }
    let groups = [
      {
        label: '词类型',
        name: 'path',
        dataSource: this.data.interfaceDataSource,
        tagName: 'RadioGroup'
      }, 
      {
        label: '版本',
        name: 'version',
        dataSource: this.state.versionDataSource,
        tagName: 'RadioGroup',
        onChange: this.versionRadioChange
      }, 
      {
        label: '排序字段',
        name: 'field',
        dataSource: fieldDataSourch,
        tagName: 'CheckboxGroup',
      }, 
      {
        label: '排序字段升序',
        name: 'order',
        dataSource: orderDataSource,
        tagName: 'CheckboxGroup',
      }, 
      {
        label: '是否核心词',
        name: 'is_core',
        dataSource: this.data.isCoreDataSource,
        tagName: 'CheckboxGroup',
      }, 
      {
        label: '是否运营',
        name: 'is_maintain',
        dataSource: this.data.isMaintainDataSource,
        tagName: 'CheckboxGroup',
      }
    ]
    return groups
  }

  render() {
    let columns = []
    if(this.state.value.version){
      columns = columnsDict[this.state.value.version]
    }
    return (
      <div style={styles.wrapper}>
        <Loadding visible={this.state.visible} />
        <IceContainer title="筛选">
          <FormBinderWrapper
            value={this.state.value}
            onChange={this.formChange}
            ref="form"
          >
            <Group groups={this.getGroups()} />
          </FormBinderWrapper>
          <div style={styles.formItem}>
            <span>排序字段优先级：</span>
            <label>{this.state.value.field.map((val, index) => (index ? ' < ' : '') + this.data.fieldsDict[val])}</label>
          </div>
          <Button type="primary" onClick={this.query}>查询</Button>
          <Button onClick={this.exportCSV} type="primary" style={styles.ml30}>导出csv</Button>
        </IceContainer>

        <IceContainer title="结果">
          <CustomTable
            dataSource={this.state.tableData}
            columns={columns}
            hasBorder={false}
            fixedHeader={true}
            maxBodyHeight={700}
          />
        </IceContainer>

        <IceContainer>
          <Pagination current={this.state.page} onChange={this.pageChange} total={this.state.total} pageSize={50} />
        </IceContainer>
      </div>
    );
  }
}
const styles = {
  formItem: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '20px'
  },
  wrapper: {
    position: 'relative'
  },
  ml30: {
    marginLeft: 30
  },
}