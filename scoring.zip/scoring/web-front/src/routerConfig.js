// 以下文件格式为描述路由的协议格式
// 你可以调整 routerConfig 里的内容
// 变量名 routerConfig 为 iceworks 检测关键字，请不要修改名称

import HeaderAsideFooterResponsiveLayout from './layouts/HeaderAsideFooterResponsiveLayout';
import BlankLayout from './layouts/BlankLayout';
import NotFound from './pages/NotFound';

import Login from './pages/Login';
import WordAlone from './pages/WordAlone';
import WordList from './pages/WordList';

const routerConfig = [
  {
    path: '/',
    layout: HeaderAsideFooterResponsiveLayout,
    component: WordAlone,
  },
  {
    path: '/WordAlone',
    layout: HeaderAsideFooterResponsiveLayout,
    component: WordAlone,
  },
  {
    path: '/wordList',
    layout: HeaderAsideFooterResponsiveLayout,
    component: WordList,
  },
  {
    path: '*',
    layout: HeaderAsideFooterResponsiveLayout,
    component: NotFound,
  },
];

export default routerConfig;
